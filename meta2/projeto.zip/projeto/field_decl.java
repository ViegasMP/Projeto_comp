class Factorial{
	public static void main(String []args){
		System.out.print("ola");
} 
//esta chaveta esta comentada}

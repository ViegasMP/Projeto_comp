//flag -e2

class Factorial {
    public static boolean b, a, c;
    public static boolean a(){;
    public static int factorial(int n) {
    }
}
